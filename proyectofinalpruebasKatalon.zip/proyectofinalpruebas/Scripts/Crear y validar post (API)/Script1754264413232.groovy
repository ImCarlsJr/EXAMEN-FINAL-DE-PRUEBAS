import static com.kms.katalon.core.testobject.ObjectRepository.findTestObject
import static com.kms.katalon.core.testdata.TestDataFactory.findTestData
import com.kms.katalon.core.webservice.keyword.WSBuiltInKeywords as WS

def data = findTestData('datosPost')

for (def i = 1; i <= data.getRowNumbers(); i++) {
    def title = data.getValue('title', i)
    def body = data.getValue('body', i)
    def userId = data.getValue('userId', i)

    def responsePost = WS.sendRequest(findTestObject('CreatePost', [
        ('title') : title,
        ('body') : body,
        ('userId') : userId
    ]))

    WS.verifyResponseStatusCode(responsePost, 201)

    def postId = WS.getElementPropertyValue(responsePost, 'id')
    println("Post creado con ID: " + postId + " con título: " + title)
}
