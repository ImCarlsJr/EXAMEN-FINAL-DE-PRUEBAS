import static com.kms.katalon.core.testcase.TestCaseFactory.findTestCase
import com.kms.katalon.core.webui.keyword.WebUiBuiltInKeywords as WebUI
import com.kms.katalon.core.model.FailureHandling as FailureHandling

WebUI.callTestCase(findTestCase('CrearPost_API'), [:], FailureHandling.STOP_ON_FAILURE)

WebUI.callTestCase(findTestCase('ValidarPost_UI'), [:], FailureHandling.STOP_ON_FAILURE)
