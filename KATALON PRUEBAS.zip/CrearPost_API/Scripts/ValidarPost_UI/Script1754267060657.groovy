import static com.kms.katalon.core.testobject.ObjectRepository.findTestObject
import com.kms.katalon.core.webui.keyword.WebUiBuiltInKeywords as WebUI

WebUI.openBrowser('')
WebUI.navigateToUrl('file:///C:/Users/carlo/OneDrive/Desktop/verPost.html')

// Espera hasta que el contenido se cargue (JavaScript tarda un poco)
WebUI.delay(3)

// Validar el contenido del post (usa el último título y cuerpo del API)
WebUI.verifyElementText(findTestObject('TituloPost'), 'Post desde API')
WebUI.verifyElementText(findTestObject('CuerpoPost'), 'Este post fue creado desde la API con Katalon.')

WebUI.closeBrowser()
