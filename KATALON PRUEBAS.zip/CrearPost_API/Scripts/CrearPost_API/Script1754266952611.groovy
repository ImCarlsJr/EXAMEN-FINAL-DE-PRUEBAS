import static com.kms.katalon.core.testobject.ObjectRepository.findTestObject
import com.kms.katalon.core.webservice.keyword.WSBuiltInKeywords as WS
import internal.GlobalVariable as GlobalVariable

def response = WS.sendRequest(findTestObject('CreatePost', [
    ('title') : 'Post desde API',
    ('body') : 'Contenido visible desde UI',
    ('userId') : '1'
]))

WS.verifyMatch(response.getStatusCode().toString(), '200|201', true)


def postId = WS.getElementPropertyValue(response, 'id')
GlobalVariable.postIdCreado = postId
